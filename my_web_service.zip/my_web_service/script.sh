#!/bin/bash
URL="http://localhost:3000/usuario"
MSG='{"nombre":"Isa","apellido":"Plaza"}'

curl -X DELETE $URL
curl -d $MSG -H "Content-Type: application/json" -X POST $URL 
curl -d $MSG -H "Content-Type: application/json" -X PUT $URL
curl -X GET $URL
